module.exports = {
    database: 'arcar',
    host: 'test-id-azure.documents.azure.com',
    username: 'test-id-azure',
    password: 'jBjv01h0WR3OCJsRorcW7kO4HeewDeDLIndm1DvPm9hjU7sNH4P73cUiTLl85Z108e1QKHuSenTdL4oQXjnqyA==',
    port: '10255',
    options: 'ssl=true&replicaSet=globaldb',
    secret: 'yoursecret'
}