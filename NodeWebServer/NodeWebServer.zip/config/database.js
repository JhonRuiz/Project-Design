module.exports = {
    database: 'carapp',
    host: 'carapptest.documents.azure.com',
    username: 'carapptest',
    password: 'Xp1pEqOrOrA28EOsbwvH4yCNomwSDgGD1IuGjU63O2mVXsqE9Ak2Hkqyq4jVr4ymNu4YJ8EWIJYQ4K2LUkOjzQ==',
    port: '10255',
    options: 'ssl=true&replicaSet=globaldb',
    secret: 'yoursecret'
}